GifAnim
http://wile64.perso.neuf.fr/download/download.php?cat=4&id=8
Version 1.4 (14/09/2009)

