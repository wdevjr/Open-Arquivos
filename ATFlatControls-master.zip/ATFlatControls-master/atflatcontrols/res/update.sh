#!/bin/bash
~/lazarus/tools/lazres icons.lrs *.bmp
