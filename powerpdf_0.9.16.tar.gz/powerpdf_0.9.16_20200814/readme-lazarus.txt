Requirements
------------
The PowerPDF components have been tested under Free Pascal 2.3.1 (r11838)
and Lazarus 0.9.27 (r16875).

Installation
------------
1) open the pack_powerpdf.lpi file in Lazarus.
2) click compile button
3) if compiling went OK, click the "Use >>" button and select "install"
4) restart the IDE, if that doesn't happen automaticaly

